"""External-process adapter contracts."""
