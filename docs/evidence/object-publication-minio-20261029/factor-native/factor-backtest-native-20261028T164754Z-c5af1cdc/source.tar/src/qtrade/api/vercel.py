from pathlib import Path
from urllib.parse import parse_qs

from starlette.types import ASGIApp, Message, Receive, Scope, Send

from qtrade.api.app import ApiAuthConfig, bootstrap_context, create_app
from qtrade.api.current_datasets import router as current_dataset_router
from qtrade.api.online_research import router as online_router
from qtrade.api.public_observations import router as observation_router
from qtrade.api.qlib_baseline import router as qlib_router
from qtrade.api.research_workflow import router as research_router
from qtrade.api.unified_data import router as unified_router
from qtrade.api.unified_market import router as unified_market_router

PROJECT_ROOT = Path(__file__).resolve().parents[3]
EVIDENCE_ROOT = PROJECT_ROOT / "deployment" / "evidence"

context = bootstrap_context()
context.research_comparison_path = EVIDENCE_ROOT / "akshare-v4" / "comparison.json"
context.research_artifact_root = EVIDENCE_ROOT / "akshare-v4"
context.walk_forward_report_path = EVIDENCE_ROOT / "akshare-walk-forward-v1.json"
context.robustness_report_path = EVIDENCE_ROOT / "akshare-robustness-v1.json"
context.factor_search_report_path = EVIDENCE_ROOT / "factor-search" / "report.json"
context.robust_factor_search_report_path = EVIDENCE_ROOT / "factor-robustness" / "report.json"
context.stock_sector_transfer_report_path = EVIDENCE_ROOT / "stock-sector-transfer" / "report.json"
context.historical_manifest_path = EVIDENCE_ROOT / "market-data" / "manifest.json"
context.minute_manifest_path = EVIDENCE_ROOT / "minute-market-data" / "manifest.json"
context.minute_research_report_path = EVIDENCE_ROOT / "minute-overlay" / "report.json"
context.five_minute_manifest_path = EVIDENCE_ROOT / "five-minute-market-data" / "manifest.json"
context.five_minute_research_report_path = (
    EVIDENCE_ROOT / "five-minute-walk-forward" / "report.json"
)
context.long_five_minute_manifest_path = (
    EVIDENCE_ROOT / "long-five-minute-market-data" / "manifest.json"
)
context.long_five_minute_research_report_path = (
    EVIDENCE_ROOT / "long-five-minute-walk-forward" / "report.json"
)
context.intraday_factor_robustness_path = (
    EVIDENCE_ROOT / "intraday-factor-long-window" / "report.json"
)
context.development_policy_search_path = (
    EVIDENCE_ROOT / "development-policy-search" / "report.json"
)
context.forward_observation_preregistration_path = (
    EVIDENCE_ROOT / "forward-observation" / "preregistration.json"
)
context.forward_observation_report_path = (
    EVIDENCE_ROOT / "forward-observation" / "report.json"
)
context.forward_source_coverage_path = (
    EVIDENCE_ROOT / "forward-source-coverage" / "report.json"
)
context.forward_source_coverage_history_path = (
    EVIDENCE_ROOT / "forward-source-coverage" / "history.json"
)
context.forward_source_coverage_release_root = (
    EVIDENCE_ROOT / "forward-source-coverage" / "releases"
)
context.reserved_tail_preregistration_path = (
    EVIDENCE_ROOT / "reserved-tail-diagnostic" / "preregistration.json"
)
context.reserved_tail_diagnostic_report_path = (
    EVIDENCE_ROOT / "reserved-tail-diagnostic" / "report.json"
)
context.public_minute_audit_path = EVIDENCE_ROOT / "public-minute-audit" / "report.json"
context.intraday_observation_path = EVIDENCE_ROOT / "intraday-observation" / "report.json"
context.intraday_breadth_path = EVIDENCE_ROOT / "intraday-breadth" / "report.json"
context.intraday_continuity_path = EVIDENCE_ROOT / "intraday-continuity" / "report.json"


class VercelQueryPathApp:
    """Restore rewrite paths and cache only anonymous successful GET responses."""

    def __init__(self, inner: ASGIApp) -> None:
        self.inner = inner

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.inner(scope, receive, send)
            return
        query = parse_qs(scope.get("query_string", b"").decode("utf-8"))
        route = query.get("route", ["/"])[0]
        if not route.startswith("/") or len(route) > 2048:
            route = "/__invalid_vercel_route__"
        routed_scope = dict(scope)
        routed_scope["path"] = route
        routed_scope["raw_path"] = route.encode("utf-8")
        request_headers = dict(scope.get("headers", []))
        cacheable_request = (
            scope.get("method") == "GET"
            and b"authorization" not in request_headers
            and b"cookie" not in request_headers
            and route not in {
                "/observations/latest", "/data-freshness", "/observations/health",
                "/persisted-experiments",
            }
            and not route.startswith("/current/")
            and not route.startswith("/qlib/")
            and not route.startswith("/research/")
            and not route.startswith("/unified/")
        )

        async def send_with_cache(message: Message) -> None:
            if (
                cacheable_request
                and message["type"] == "http.response.start"
                and 200 <= message["status"] < 300
            ):
                cached_message = dict(message)
                headers = list(message.get("headers", []))
                headers.extend(
                    (
                        (b"cache-control", b"public, max-age=15"),
                        (
                            b"vercel-cdn-cache-control",
                            b"public, max-age=60, stale-while-revalidate=300",
                        ),
                    )
                )
                cached_message["headers"] = headers
                await send(cached_message)
                return
            await send(message)

        await self.inner(routed_scope, receive, send_with_cache)


inner_app = create_app(context, auth=ApiAuthConfig())
inner_app.include_router(observation_router)
inner_app.include_router(current_dataset_router)
inner_app.include_router(qlib_router)
inner_app.include_router(research_router)
inner_app.include_router(unified_router)
inner_app.include_router(unified_market_router)
inner_app.include_router(online_router)
app = VercelQueryPathApp(inner_app)
