"""Q quantitative trading platform."""

__version__ = "0.1.0"
