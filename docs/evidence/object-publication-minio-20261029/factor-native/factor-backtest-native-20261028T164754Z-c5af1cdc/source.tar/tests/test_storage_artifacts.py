import os
import stat
from dataclasses import replace
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal
from hashlib import sha256

import pyarrow as pa  # type: ignore[import-untyped]
import pyarrow.parquet as pq  # type: ignore[import-untyped]
import pytest

from qtrade.data import (
    Bar,
    DataManifest,
    DatasetIntegrityError,
    ParquetBarStore,
    QualityStatus,
)
from qtrade.persistence import ExperimentCatalogEntry, SQLiteMetadataCatalog
from qtrade.research import ExperimentArtifactStore, ExperimentRecord, TimeSplit


def manifest() -> DataManifest:
    return DataManifest(
        data_version="bars-v1",
        source="test-fixture",
        schema_version="1",
        ingestion_time=datetime(2026, 8, 12, tzinfo=UTC),
        checksum="pending",
        quality_status=QualityStatus.PENDING,
    )


def sample_bar() -> Bar:
    return Bar(
        "510300",
        "SSE",
        datetime(2026, 8, 12, 7, tzinfo=UTC),
        date(2026, 8, 12),
        Decimal("10"),
        Decimal("11"),
        Decimal("9"),
        Decimal("10.5"),
        Decimal("100"),
    )


def test_parquet_store_requires_quality_and_checksum(tmp_path):
    store = ParquetBarStore(tmp_path)
    bar = Bar(
        "510300",
        "SSE",
        datetime(2026, 8, 12, 7, tzinfo=UTC),
        date(2026, 8, 12),
        Decimal("10"),
        Decimal("11"),
        Decimal("9"),
        Decimal("10.5"),
        Decimal("100"),
    )
    passed = store.write([bar], manifest())
    assert passed.quality_status is QualityStatus.PASSED
    assert store.read(passed) == [bar]
    target = tmp_path / "bars-v1" / "bars.parquet"
    target.write_bytes(target.read_bytes() + b"tampered")
    with pytest.raises(DatasetIntegrityError, match="checksum"):
        store.read(passed)


def test_parquet_store_cleans_failed_write_and_allows_retry(tmp_path, monkeypatch):
    store = ParquetBarStore(tmp_path)
    original_write_table = pq.write_table
    write_attempts = 0

    def fail_once(*args, **kwargs):
        nonlocal write_attempts
        write_attempts += 1
        if write_attempts == 1:
            raise OSError("simulated parquet write failure")
        return original_write_table(*args, **kwargs)

    monkeypatch.setattr(pq, "write_table", fail_once)

    with pytest.raises(OSError, match="simulated parquet write failure"):
        store.write([sample_bar()], manifest())

    assert list(tmp_path.iterdir()) == []
    passed = store.write([sample_bar()], manifest())
    assert store.read(passed) == [sample_bar()]
    assert [path.name for path in tmp_path.iterdir()] == ["bars-v1"]
    target = tmp_path / "bars-v1" / "bars.parquet"
    persisted = target.read_bytes()

    with pytest.raises(FileExistsError):
        store.write([sample_bar()], manifest())

    assert target.read_bytes() == persisted


def test_parquet_store_syncs_file_and_directories_before_return(tmp_path, monkeypatch):
    synced_types: list[str] = []
    real_fsync = os.fsync

    def track_fsync(file_descriptor: int) -> None:
        mode = os.fstat(file_descriptor).st_mode
        synced_types.append("directory" if stat.S_ISDIR(mode) else "file")
        real_fsync(file_descriptor)

    monkeypatch.setattr(os, "fsync", track_fsync)

    ParquetBarStore(tmp_path).write([sample_bar()], manifest())

    assert synced_types == ["file", "directory", "directory"]


def test_parquet_store_rejects_row_data_version_drift(tmp_path):
    store = ParquetBarStore(tmp_path)
    bar = Bar(
        "510300",
        "SSE",
        datetime(2026, 8, 12, 7, tzinfo=UTC),
        date(2026, 8, 12),
        Decimal("10"),
        Decimal("11"),
        Decimal("9"),
        Decimal("10.5"),
        Decimal("100"),
    )
    passed = store.write([bar], manifest())
    target = tmp_path / "bars-v1" / "bars.parquet"
    table = pq.read_table(target)
    version_index = table.schema.get_field_index("data_version")
    pq.write_table(
        table.set_column(
            version_index,
            "data_version",
            pa.array(["bars-v2"]),
        ),
        target,
        compression="zstd",
    )
    resigned = replace(passed, checksum=sha256(target.read_bytes()).hexdigest())

    with pytest.raises(DatasetIntegrityError, match="data_version"):
        store.read(resigned)


def test_parquet_store_rejects_resigned_physical_timestamp_disorder(tmp_path):
    store = ParquetBarStore(tmp_path)
    first = Bar(
        "510300",
        "SSE",
        datetime(2026, 8, 12, 7, tzinfo=UTC),
        date(2026, 8, 12),
        Decimal("10"),
        Decimal("11"),
        Decimal("9"),
        Decimal("10.5"),
        Decimal("100"),
    )
    second = replace(first, timestamp=first.timestamp + timedelta(minutes=5))
    passed = store.write([first, second], manifest())
    target = tmp_path / "bars-v1" / "bars.parquet"
    table = pq.read_table(target)
    pq.write_table(
        table.take(pa.array([1, 0])),
        target,
        compression="zstd",
    )
    resigned = replace(passed, checksum=sha256(target.read_bytes()).hexdigest())

    with pytest.raises(DatasetIntegrityError, match="quality gate"):
        store.read(resigned)


@pytest.mark.parametrize("mutation", ["missing", "extra", "reordered", "type"])
def test_parquet_store_rejects_resigned_schema_drift(tmp_path, mutation):
    store = ParquetBarStore(tmp_path)
    bar = Bar(
        "510300",
        "SSE",
        datetime(2026, 8, 12, 7, tzinfo=UTC),
        date(2026, 8, 12),
        Decimal("10"),
        Decimal("11"),
        Decimal("9"),
        Decimal("10.5"),
        Decimal("100"),
    )
    passed = store.write([bar], manifest())
    target = tmp_path / "bars-v1" / "bars.parquet"
    table = pq.read_table(target)
    if mutation == "missing":
        table = table.drop(["close"])
    elif mutation == "extra":
        table = table.append_column("unexpected", pa.array(["value"]))
    elif mutation == "reordered":
        table = table.select(
            ["exchange", "symbol", *table.column_names[2:]],
        )
    else:
        timestamp_index = table.schema.get_field_index("timestamp")
        table = table.set_column(timestamp_index, "timestamp", pa.array([1]))
    pq.write_table(table, target, compression="zstd")
    resigned = replace(passed, checksum=sha256(target.read_bytes()).hexdigest())

    with pytest.raises(DatasetIntegrityError, match="schema"):
        store.read(resigned)


def test_parquet_store_write_rejects_data_version_path_escape(tmp_path):
    store = ParquetBarStore(tmp_path / "root")
    escaped = replace(manifest(), data_version="../escaped-write")

    with pytest.raises(DatasetIntegrityError, match="path"):
        store.write([sample_bar()], escaped)

    assert not (tmp_path / "escaped-write").exists()


def test_parquet_store_read_rejects_data_version_path_escape(tmp_path):
    passed = ParquetBarStore(tmp_path / "outside").write([sample_bar()], manifest())
    escaped = replace(passed, data_version="../outside/bars-v1")
    (tmp_path / "root").mkdir()

    with pytest.raises(DatasetIntegrityError, match="path"):
        ParquetBarStore(tmp_path / "root").read(escaped)


def test_parquet_store_rejects_checksum_valid_invalid_parquet(tmp_path):
    target = tmp_path / "bars-v1" / "bars.parquet"
    target.parent.mkdir()
    target.write_bytes(b"not-a-parquet-file")
    passed = replace(
        manifest(),
        checksum=sha256(target.read_bytes()).hexdigest(),
        quality_status=QualityStatus.PASSED,
    )

    with pytest.raises(DatasetIntegrityError, match="decoding"):
        ParquetBarStore(tmp_path).read(passed)


def test_parquet_store_rejects_resigned_empty_dataset(tmp_path):
    store = ParquetBarStore(tmp_path)
    passed = store.write([sample_bar()], manifest())
    target = tmp_path / "bars-v1" / "bars.parquet"
    pq.write_table(pq.read_table(target).slice(0, 0), target, compression="zstd")
    resigned = replace(passed, checksum=sha256(target.read_bytes()).hexdigest())

    with pytest.raises(DatasetIntegrityError, match="empty"):
        store.read(resigned)


@pytest.mark.parametrize(
    ("column", "values"),
    [
        ("close", pa.array([None], type=pa.string())),
        ("timestamp", pa.array(["not-a-time"])),
    ],
)
def test_parquet_store_normalizes_resigned_row_decode_failures(
    tmp_path,
    column,
    values,
):
    store = ParquetBarStore(tmp_path)
    passed = store.write([sample_bar()], manifest())
    target = tmp_path / "bars-v1" / "bars.parquet"
    table = pq.read_table(target)
    column_index = table.schema.get_field_index(column)
    pq.write_table(
        table.set_column(column_index, column, values),
        target,
        compression="zstd",
    )
    resigned = replace(passed, checksum=sha256(target.read_bytes()).hexdigest())

    with pytest.raises(DatasetIntegrityError, match="row decoding"):
        store.read(resigned)


def test_experiment_artifacts_are_hashed_and_immutable(tmp_path):
    record = ExperimentRecord(
        experiment_id="exp-1",
        git_commit="abc123",
        data_version="bars-v1",
        universe=("510300",),
        factor_set=("trend",),
        label="next_return",
        split=TimeSplit(
            date(2020, 1, 1),
            date(2022, 12, 31),
            date(2023, 1, 1),
            date(2023, 12, 31),
            date(2024, 1, 1),
            date(2024, 12, 31),
        ),
        model="baseline",
        hyperparameters={},
        seed=7,
        transaction_cost=Decimal("0.001"),
        metrics={"return": Decimal("0.1")},
        artifacts=("report.json",),
    )
    store = ExperimentArtifactStore(tmp_path)
    target, digest = store.save(record)
    assert digest in target.read_text(encoding="utf-8")
    with pytest.raises(FileExistsError):
        store.save(record)


def test_sqlite_metadata_catalog_preserves_dataset_experiment_lineage(tmp_path):
    catalog = SQLiteMetadataCatalog(tmp_path / "metadata.db")
    passed = DataManifest(
        "bars-v1",
        "licensed-vendor",
        "1",
        datetime(2026, 8, 12, tzinfo=UTC),
        "checksum-1",
        QualityStatus.PASSED,
    )
    catalog.register_dataset(passed)
    catalog.register_dataset(passed)
    entry = ExperimentCatalogEntry("exp-1", "spec-hash", "abc123", "bars-v1", "exp-1.json")
    catalog.register_experiment(entry)
    catalog.register_experiment(entry)

    restarted = SQLiteMetadataCatalog(tmp_path / "metadata.db")
    assert restarted.dataset_versions() == ("bars-v1",)
    assert restarted.experiments() == (entry,)
    with pytest.raises(ValueError, match="conflicts"):
        restarted.register_dataset(
            DataManifest(
                "bars-v1",
                "licensed-vendor",
                "1",
                datetime(2026, 8, 12, tzinfo=UTC),
                "changed",
                QualityStatus.PASSED,
            )
        )
    with pytest.raises(ValueError, match="unknown data_version"):
        restarted.register_experiment(
            ExperimentCatalogEntry("bad", "hash", "abc", "missing", "bad.json")
        )
