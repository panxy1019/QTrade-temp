"""External-process adapter contracts."""
