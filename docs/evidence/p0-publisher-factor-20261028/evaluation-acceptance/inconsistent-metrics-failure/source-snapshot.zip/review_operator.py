
import importlib.util, json, pathlib
from copy import deepcopy
from hashlib import sha256
import pyarrow.parquet as pq
from qtrade.research import factor_evaluation as evaluation
root=pathlib.Path.cwd()
spec=importlib.util.spec_from_file_location("review_fixture", root/"tests/test_daily_factor_evaluation.py")
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
build,evaluate,request,database,registry,days=fixture.setup.__wrapped__(root.parent/"temporary-fixture")
version,raw=build()
request=deepcopy(request)
request["ordered_factor_refs"]=[request["ordered_factor_refs"][1]]
request["decisions"]=request["decisions"][:1]
reads=[]
original=pq.read_table
def traced(*args,**kwargs):
 table=original(*args,**kwargs)
 reads.append({"rows":table.num_rows,"columns":table.column_names,"has_filters":"filters" in kwargs})
 return table
pq.read_table=traced
report=evaluate(version,request)
changed=deepcopy(report)
changed["documents"]["daily_metrics"]["0"][0]["ic"]="0.1234567"
manifest={name:evaluation._hash(document) for name,document in changed["documents"].items()}
changed["report_manifest"]=manifest
changed["report_manifest_sha256"]=evaluation._hash(manifest)
changed["specification_sha256"]=manifest["specification"]
accepted=False;error=None
try:
 evaluation.validate_report(changed);accepted=True
except Exception as exc:
 error=type(exc).__name__+":"+str(exc)
print(json.dumps({"source_hashes":{name:sha256((root/name).read_bytes()).hexdigest() for name in ["src/qtrade/research/factor_evaluation.py","src/qtrade/research/factor_registry.py","scripts/run_daily_factor_evaluation.py","tests/test_daily_factor_evaluation.py"]},"read_calls":reads,"scoring_dependency_cells":len(request["instruments"])*len(request["decisions"])*6,"required_calendar_rows_per_security":7,"resigned_inconsistent_metric_accepted":accepted,"validator_error":error,"scope":"TINY_SYNTHETIC_NONPRODUCTION_SNAPSHOT_ONLY"},sort_keys=True,indent=2))
