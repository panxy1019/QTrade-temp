# STEP2 四因子接口独立验收与归档读取修复

2026-10-28。本轮只操作本机合成临时 READY/Parquet、独立测试与既有报告的只读
重放；没有集群、网页、生产 API、PAPER、ACTIVE、服务或订单操作。
`LIVE_TRADING_ENABLED=false` 保持。原实验、签名数据、共享状态文档没有改写。

## 范围与来源

先读取 AGENTS、CURRENT_STATE、MASTER_PLAN、DECISIONS（特别是 ADR-201/203/204）、
四因子登记/评价进展与 Strategy 接口审计，再检查实际实现及原有测试。
沿用已记录的 vn.py 缺口结论：网关不承担 READY 身份、因子内容版本、双时钟及
研究报告重放合同。本轮复用现有 FactorRegistry、DataVersionCatalog、评价器和
SQLite 不可变 INSERT，没有另建登记器、指标框架或执行路径。

新增 [独立测试](../tests/test_step2_factor_contract_independent.py)，修复
[factor_evaluation.py](../src/qtrade/research/factor_evaluation.py) 的报告读取验证。
测试自行构造 8 个证券、31 个价格会话和一个占位日历边界，使用 5 个连续决策会话
及四项既有定义。没有导入原测试 fixture、PriceFactorSpec 或项目指标作为数值真值。
测试中的 revision 字符串仅是合成标签，执行来源由实际源文件摘要绑定。

## 实际发现及修复前失败

原 `validate_report` 能发现摘要变化和指标数值不一致，但在重新计算各文档摘要后，
下面三种时点矛盾均通过验证：

1. OBSERVED_SYSTEM 已接受样本的一个 observed_at 改为未来时点。
2. history_sessions 最后一个会话改成未来日期。
3. label_exit_session 改成未来日期，保留有效标签和数值指标。

独立测试实际得到 **3 failed，14 deselected**，均为 `DID NOT RAISE ValueError`；
没有使用 xfail。修复前 JUnit、完整评价源码及独立测试源码保存在本机：
`E:/QTrade-temp/step2-factor-contract-acceptance-20261028/red-temporal.xml`、
`red-factor_evaluation.py`、`red-test_step2_factor_contract_independent.py`。
修复前评价源码 SHA256 为
`782f245d2845ab6b06e18c8c99aa7f844fae2f953fde96e4604a99a4c76e5b3d`。

首次修复后的整组运行记录另存 `first-fix.xml`：81 passed、1 failed。
该失败来自独立组合 oracle 将“逐因子百分位再平均”改成“秩求和后除”，在 Decimal
精度 28 下引入不同的 ties。已按登记的逐因子百分位政策纠正 oracle，没有放宽
RankIC 容差或修改实现来迎合错误预期。此前失败记录仍保留。

## 窄修合同

归档读取现在从保存的请求和日历重新推导历史网格及标签端点，验证：

- 日历日期规范、排序、唯一、摘要和 READY 起止日；决策确属连续共同会话。
- 每个因子需要的共同历史长度、逐依赖会话、时钟字段及条数，不接受错位或缺条。
- available_at/observed_at 必须可解析为带时区时点；known/clock_reason 与保存时钟
  一致。OBSERVED_SYSTEM 有效特征必须在精确决策屏障前已知；事后模式仍允许明确
  披露的未知/迟到时钟，没有把事后结果升级为历史实际计算。
- 标签端点恰为冻结日历的 t+h；15:00 上海计划成熟与保存的成熟拒绝原因一致。
  测试包含真实历史屏障前一微秒，并非只拒绝 2099 这一特殊日期。
- 完整十文件来源清单、因子定义来源摘要与归档源码摘要一致；规格 schema、证券
  范围、价格基础及频率匹配，归档也重新执行非生产依赖单元限额。

原来的摘要、固定政策、逐样本/逐日指标、分组、换手、稳定性、冗余及汇总复算仍
保留。未改变因子数学语义、请求格式、报告 schema 或旧归档身份。

## 独立验收覆盖

| 合同 | 实际检查 |
| --- | --- |
| 精确版本 | 未知 id/版本、latest、摘要不匹配、缺字段、重复引用拒绝；评价边界重新核对合成依赖存在 |
| 输入时点 | 双时钟分别覆盖恰好屏障、晚一微秒、未知；事后模式保留原时钟且可正常重验 |
| 特征/标签隔离 | 改变未来标签价格不改变特征；退出标签任一时钟晚于屏障均不计有效样本 |
| 部分覆盖 | 缺共同会话、非正价格、缺标签分别披露；保留全部候选 ledger/sample，按因子实际配对 |
| 缺失指标 | 未成熟标签保持 null、无分组和明确原因；因子间冗余仍按独立有效特征计算 |
| 数值 | 从原合成 close 直接计算四因子，独立 Pearson/平均 ties 秩、分组及高低组差/换手；比较 IC/RankIC、ddof1 IR、固定稳定性 blocks 和六组冗余 |
| 不可覆盖 | 同 evaluation_id 的另一份有效报告被拒绝；旧 payload/hash 不变；新身份可链接原评价追加复验 |
| 归档合同 | 重新摘要后的未来/迟到/未知时钟、错误或缺失网格、虚假 known、错标签端点/成熟度、范围和来源漂移拒绝 |

数值 oracle 使用 Python 标准库的数学/统计函数，容差 2e-13；不是另一供应商、另一
Python 运行时或独立价格源的认证。恒定/不足样本及 CLI/硬链接/失败尝试等已有
检查也随本次回归运行，没有以新测试替代它们。

## 验证与旧实验兼容性

新增独立测试 **32 项通过**；最终目标回归包括原 registry/evaluation、合同准备、
factor_search 与 signal_baselines，合计 **120 passed，0 failed/errors/skipped**，
耗时 26.35 秒。JUnit 保存在同一临时证据目录的 `regression-final.xml`。
Ruff 和评价模块定向 mypy 通过，`git diff --check` 通过。

原 891 股五日实验 `factor-eval-9ca107f1ff4843769b813d4b663eed63` 已通过修复后读取器
重验，报告 manifest SHA256 仍为
`61208f117890d0a453e084f92b6edc1d6b931b195d415b1b184104d72fbdb536`。
原 report.json.gz 的 SHA256 重放前后均为
`47bed3add84aff16f901531115c17ac4534cfd667b6716595a1ce098b9af37dd`。
独立只读重放收据为本机 `archived-replay-final.json`，耗时约 1.26 秒。
这只是原报告内部合同/数值的重新验算，没有重跑或覆盖原实验。

最终读取器源码 SHA256：
`3e1c6b4c57a4483fac160d7b410daa28eede4d75580fe9383e3ea1f6c3815f8f`。

复现（仓库根目录、本机临时合成数据）：

```powershell
$env:PYTHONPATH = 'src;.'
$env:LIVE_TRADING_ENABLED = 'false'
python -m pytest tests/test_step2_factor_contract_independent.py tests/test_daily_factor_evaluation.py tests/test_factor_registry.py tests/test_step2_factor_contract_readiness.py tests/test_factor_search.py tests/test_signal_baselines.py
python -m ruff check src/qtrade/research/factor_evaluation.py tests/test_step2_factor_contract_independent.py
python -m mypy src/qtrade/research/factor_evaluation.py --follow-imports=silent
```

## 限制

v1 原归档没有标签退出行的 available_at/observed_at，也没有资格 interval 文件的
原文字节。本次可重验已保存的特征双时钟、标签端点和计划成熟合同，不能仅凭旧
bundle 独立重建标签源时钟、资格事实或原始价格真实性；这些仍须原 READY 版本。
生成路径本身对退出标签双时钟仍有拒绝式校验，本次新增测试实际覆盖了该路径。

内容摘要是内部一致性检查，不是有权重写全部档案者无法伪造的密码学签名。
本次仅本地 Windows 验证；没有新 Linux/集群运行、性能/SLA 或断电认证。
原五日实验的选择/生存者、已看历史、PIT/复权未认证及短窗口限制继续保留。
独立因子报告到 StrategySpec/Builder/生产 API 的接线仍未完成；本验收不授予
因子优越性、模型晋级、PAPER 恢复、生产或真实交易权限。
